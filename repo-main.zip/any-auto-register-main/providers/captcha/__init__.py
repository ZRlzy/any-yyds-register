"""Captcha provider plugins."""
